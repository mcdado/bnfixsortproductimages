# Fix Sort Product Images

See https://github.com/PrestaShop/PrestaShop/pull/8666

## Credits

Made by [Brand New srl](http://brandnew.sm).
